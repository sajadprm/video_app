<div id="related-posts">
    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="related-video-item">
            <div class="thumb">
                <small class="time"><?php echo e($video->lengthInHuman); ?></small>
                <a href="<?php echo e(route('videos.show', $video->slug)); ?>"><img src="<?php echo e($video->thumbnail); ?>" alt=""></a>
            </div>
            <a href="<?php echo e(route('videos.show', $video->slug)); ?>" class="title"><?php echo e($video->name); ?></a>
            <a class="channel-name" href="#">داود طاهری<span>
                    <i class="fa fa-check-circle"></i></span></a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/saami/Desktop/Projects/Laravel-Basic/src/resources/views/components/related-videos.blade.php ENDPATH**/ ?>