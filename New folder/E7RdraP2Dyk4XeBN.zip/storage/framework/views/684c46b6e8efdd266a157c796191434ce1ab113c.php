{ $array = [1,2,3,4,5,6] }

<?php echo e(dd($array)); ?>

<?php $__currentLoopData = [1,2,3,4,5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e(dd($value)); ?>

<i><?php echo e($value); ?></i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/saami/Desktop/Projects/Laravel-Basic/src/resources/views/users.blade.php ENDPATH**/ ?>