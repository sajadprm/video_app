    <div id="main-category">
        <div class="container-full">
            <div class="row">
                <div class="col-md-12">
                    <ul class="main-category-menu">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="color-1"><a
                                    href="<?php echo e(route('categories.videos.index', $category->slug)); ?>"><i
                                        class="<?php echo e($category->icon); ?>"></i><?php echo e($category->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div><!-- // col-md-14 -->
            </div><!-- // row -->
        </div><!-- // container-full -->
    </div><!-- // main-category -->
<?php /**PATH /home/saami/Desktop/Projects/Laravel-Basic/src/resources/views/components/header-menu.blade.php ENDPATH**/ ?>